function Expense(id, name, cost, remarks, date, color, photo){

    this.id = id;
    this.name = name;
    this.cost = cost;
    this.remarks = remarks;
    this.date = date;
    this.color = color;
    this.photo = photo;
    this.isMarked = false;

    }