window.addEventListener('load', init);

function bindEvents() {
    document.querySelector('#add').addEventListener('click',add);
    document.querySelector('#delete').addEventListener('click', deleteMarked);
     
}

function deleteMarked() {
    reportcardOperations.removeMark();
    printReportcards();


}
function printReportcards() {
    document.querySelector('#reportcards').innerHTML = '';
    reportcardOperations.getReportcards().forEach(printReportcard);
    updateCount();
}

function init() {
    bindEvents();
    updateCount();
}

function updateCount() {
    document.querySelector('#total').innerText = reportcardOperations.len();
    document.querySelector('#mark').innerText = reportcardOperations.countMark();
    document.querySelector('#unmark').innerText = reportcardOperations.len() - reportcardOperations.countMark();
}

function add() {
    let roll = document.querySelector('#roll').value;
    let name = document.querySelector('#name').value;
    let date = document.querySelector('#date').value;
    let marks = document.querySelector('#marks').value;
    let remarks = document.querySelector('#remarks').value;
    
    let reportcardObject = reportcardOperations.add(roll, name, date, marks, remarks);
    printReportcard(reportcardObject);
    updateCount();
}
function edit() {
    console.log('I am edit');
}

function mark() {
    console.log('I am Mark ', this);
    let id = this.getAttribute('eid');
    reportcardOperations.findById(id);
    updateCount();
    //this.parentNode.parentNode.classList.d
    this.parentNode.parentNode.classList.toggle('alert-danger');
}


function printReportcard(reportcardObject) {
    let tbody = document.querySelector('#reportcards');
    let tr = tbody.insertRow();
    let index = 0;
    for (let key in reportcardObject) {
        if (key == 'isMarked') {
            continue;
        }
        tr.insertCell(index).innerText = reportcardObject[key];
        index++;
        console.log(reportcardObject[key]);
    }

   
    let td = tr.insertCell(index);
    

}