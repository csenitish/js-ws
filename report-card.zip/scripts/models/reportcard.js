function Reportcard(roll, name, date, marks, remarks){

    this.roll = roll;
    this.name = name;
    this.date = date;
    this.marks = marks;
    this.remarks = remarks;
    this.isMarked = false;
    

    }