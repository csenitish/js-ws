const reportcardOperations = {
    reportcards:[],

    add(roll, name, date, marks, remarks){
        var reportcardObject = new Reportcard(roll, name, date, marks, remarks);
        this.reportcards.push(reportcardObject);
        return reportcardObject;
    },
    getReportcard(){
        return this.reportcards;
    },
   

    len(){
        return this.reportcards.length;
    },
  
    
    
   
}

